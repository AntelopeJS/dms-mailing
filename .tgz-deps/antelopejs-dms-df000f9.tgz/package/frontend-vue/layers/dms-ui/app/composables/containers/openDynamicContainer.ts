import type { Component } from "vue";
import type { ContainerInstance, ContainerOptions } from "./types";

type Overlay = ReturnType<typeof useOverlay>;

/**
 * Defer `open` until any closing Reka UI menu has left the DOM.
 *
 * When a container is opened from a menu (e.g. the table-view row-actions
 * dropdown's "View details"), the menu is still animating closed. Opening a
 * drawer/modal overlay while the menu is mid-close lets the menu's teardown
 * (focus return + dismiss events) instantly dismiss the fresh overlay — it
 * flashes in and back out, so nothing shows. So we poll until no `[role="menu"]`
 * remains, then leave a short beat for its focus handling to settle before
 * opening. Paths with no open menu (row double-click, direct calls) open on the
 * spot. Returns a canceller so a pending open can be aborted (see `close`).
 */
function openWhenMenusClosed(open: () => void): () => void {
  if (
    typeof document === "undefined" ||
    !document.querySelector('[role="menu"]')
  ) {
    open();
    return () => {};
  }

  const STEP_MS = 32;
  const MAX_MS = 800;
  const SETTLE_MS = 60;
  let waited = 0;
  let settleTimer: ReturnType<typeof setTimeout> | null = null;
  const poll = setInterval(() => {
    waited += STEP_MS;
    if (document.querySelector('[role="menu"]') && waited < MAX_MS) return;
    clearInterval(poll);
    settleTimer = setTimeout(open, SETTLE_MS);
  }, STEP_MS);

  return () => {
    clearInterval(poll);
    if (settleTimer !== null) clearTimeout(settleTimer);
  };
}

/**
 * Shared opening logic behind {@link useDrawer} and {@link useModal}: create the
 * themed overlay, ensure a unique `containerId` for the leave-guard system, mark
 * the body component raw so Vue keeps it as-is, and expose the open `result`
 * promise together with a programmatic `close`.
 */
export function openDynamicContainer<Result, Options extends ContainerOptions>(
  overlay: Overlay,
  container: Component,
  idPrefix: string,
  options: Options,
): ContainerInstance<Result> {
  const { component, headerComponent, containerId, ...rest } = options;
  const instance = overlay.create(container, {
    props: {
      ...rest,
      containerId: containerId ?? `${idPrefix}-${crypto.randomUUID()}`,
      component: markRaw(component),
      ...(headerComponent && { headerComponent: markRaw(headerComponent) }),
    },
  });

  let opened = false;
  let resolveResult!: (value: Result) => void;
  let rejectResult!: Parameters<
    ConstructorParameters<typeof Promise<Result>>[0]
  >[1];
  const result = new Promise<Result>((resolve, reject) => {
    resolveResult = resolve;
    rejectResult = reject;
  });
  const cancelPendingOpen = openWhenMenusClosed(() => {
    opened = true;

    instance.open().then(resolveResult, rejectResult);
  });

  return {
    result,
    patch: (patch) => instance.patch(patch),
    close: (value?: Result) => {
      if (opened) {
        instance.close(value);
      } else {
        cancelPendingOpen();
        instance.close(value);
        // oxlint-disable-next-line anti-slop/require-safety-comment-for-type-assertion -- Closing before open historically resolves undefined when no value is passed, even for a non-optional Result.
        resolveResult(value as Result);
      }
    },
  };
}
